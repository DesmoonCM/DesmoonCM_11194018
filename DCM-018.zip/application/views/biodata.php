<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body bgcolor="white">
	<h1><u>MY BIODATA</u></h1>
	<h3>NAMA : DESMOON C MONGKAU</h3>
	<h3>TEMPAT TGL LAHIR : UJUNG PANDANG 06-12-1999 </h3>
	<h3>UMUR : 21 </h3>
	<h3>NO.HP : 082292680855 </h3>
	<h3>ALAMAT : ASPOL ANTANG </h3>
</body>
</html>